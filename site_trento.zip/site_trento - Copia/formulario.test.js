const { validarSenha, validarIdade, validarConfirmacaoSenha, enviarFormulario } = require('./formulario');

describe('Validação de Senha', () => {
    test('deve identificar se a senha cumpre todos os reuisitos', () =>{
        const resultado = validarSenha('Senha123!');
        expect(resultado.letraMaiuscula || resultado.contemNumero || resultado.caracterEspecial).toBe(true);
    });

    test('deve identificar se a senha não contém letra maiúscula', () => {
        const resultado = validarSenha('senha123!');
        expect(resultado.letraMaiuscula).toBe(false);
    });

    test('deve identificar se a senha não contém caracter especial', () => {
        const resultado = validarSenha('Senha123');
        expect(resultado.caracterEspecial).toBe(false);
    });

    test('deve identificar se a senha não contém número', () => {
        const resultado = validarSenha('Senha!');
        expect(resultado.contemNumero).toBe(false);
    });
});

describe('Validação de Idade', () => {
    test('deve permitir usuários com 18 anos ou mais', () => {
        expect(validarIdade(18)).toBe(true);
        expect(validarIdade(20)).toBe(true);
    });

    test('não deve permitir usuários com menos de 18 anos', () => {
        expect(validarIdade(17)).toBe(false);
        expect(validarIdade(15)).toBe(false);
    });
});

describe('Validação de Confirmação de Senha', () => {
    test('deve confirmar se as senhas coincidem', () => {
        expect(validarConfirmacaoSenha('Senha123!', 'Senha123!')).toBe(true);
    });

    test('não deve confirmar se as senhas não coincidem', () => {
        expect(validarConfirmacaoSenha('Senha123!', 'Senha456!')).toBe(false);
    });
});

describe('Envio do Formulário', () => {
    test('deve retornar mensagem de erro se idade for menor de 18 anos', () => {
        const resultado = enviarFormulario(17, 'Senha123!', 'Senha123!');
        expect(resultado).toBe('Menores de 18 anos não podem enviar o formulário!');
    });

    test('deve retornar mensagem de erro se as senhas não coincidirem', () => {
        const resultado = enviarFormulario(20, 'Senha123!', 'Senha456!');
        expect(resultado).toBe('Senhas diferentes.');
    });

    test('deve retornar mensagem de erro se a senha não atender aos critérios', () => {
        const resultado = enviarFormulario(20, 'senha', 'senha');
        expect(resultado).toBe('Senha inválida.');
    });

    test('deve retornar mensagem de sucesso se todas as validações forem bem-sucedidas', () => {
        const resultado = enviarFormulario(20, 'Senha123!', 'Senha123!');
        expect(resultado).toBe('Formulário enviado com sucesso!');
    });
});